# random
a python module to get random numbers from random.org

# basic implementation
import the module 
```python
import randomorg
```

initialize the generator 
```python
randomgen = Generator(apikey = "API_KEY_HERE")
```

generate a number

```python
randomgen.randint()
```

for documentation go [here](http://github.com/ellipticobj/random-module/DOCUMENTATION.md)